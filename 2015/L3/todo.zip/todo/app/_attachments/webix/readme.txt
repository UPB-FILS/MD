Webix UI v.3.0.6
================

http://webix.com

If you don't know where to start - check 

- http://webix.com/quick-start/#!/1
- http://docs.webix.com/desktop__getting_started.html
- http://forum.webix.com

### License terms

Webix UI library is licensed under "GPL v3" licence
http://www.gnu.org/licenses/old-licenses/gpl-3.0.html

### What does it means in human terms

- You CAN'T remove this license or webix attribution from source files
- You CAN modify provided code in any way which doesn't conflict with above statement

- You CAN use this lib for any private projects which you do not plan to share or sell
- You CAN use this lib for public projects, BUT in such case you MUST share full source code of your project
- If you do not want to share sources then you need to obtain commercial license


### Commercial license and Support

You can buy commercial license and support subscription at http://webix.com


(c) XB Software Ltd. 2015